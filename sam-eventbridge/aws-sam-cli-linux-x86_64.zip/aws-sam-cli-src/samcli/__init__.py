"""
SAM CLI version
"""

__version__ = "1.124.0"
